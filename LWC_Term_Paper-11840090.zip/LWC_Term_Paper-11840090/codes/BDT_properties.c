#include<stdio.h>
unsigned char sbox[16]=          {0xc,0x5,0x6,0xb,0x9,0x0,0xa,0xd,0x3,0xe,0xf,0x8,0x4,0x7,0x1,0x2};
unsigned char inverse_sbox[16] = {0x5,0xe,0xf,0x8,0xc,0x1,0x2,0xd,0xb,0x4,0x6,0x3,0x0,0x7,0x9,0xa};

int main()
{
    unsigned char a[16][16][16]={0},delta1;
    for(int x=0;x<16;x++)
    {
        for(int i=0;i<16;i++)
        {
           for(int j=0;j<16;j++)
           {
              //delta1=(sbox[x]^sbox[x^i]);
              if(((inverse_sbox[sbox[x]^j])^(inverse_sbox[sbox[x^i]^j]))==i)
              {
                   for(int k=0;k<16;k++)
                   if((sbox[x]^sbox[x^i])==k)
                   a[i][k][j]++;
              }
           }
        }
    }
   printf("\n-----------------Property 1--------------------\n");
    for(int i=0;i<16;i++)
    {
       for(int j=0;j<16;j++)
       {   
         for(int k=0;k<1;k++)
         {
         if(a[i][j][k]<10)
         printf(" %d ",a[i][j][k]);
         else
         printf("%d ",a[i][j][k]);
         }
       }
       printf("\n");
    }
    printf("\n-----------------Property 2--------------------\n");
    int sum=0;
    for(int i=0;i<16;i++)
    {
       for(int j=0;j<16;j++)
       {   sum=0;
         for(int k=0;k<16;k++)
         {
         sum+=a[i][k][j];
         }
         if(sum<10)
         printf(" %d ",sum);
         else
         printf("%d ",sum);
         
       }
       printf("\n");
    }
    printf("\n-----------------Property 3--------------------\n");
    for(int i=0;i<1;i++)
    {
       for(int j=0;j<1;j++)
       {   
         for(int k=0;k<16;k++)
         {
         sum=a[i][j][k];
         if(sum<10)
         printf(" %d ",sum);
         else
         printf("%d ",sum);
         
         }
         
       }
       printf("\n");
    }
     printf("\n-----------------Property 4--------------------\n");
    int sum1=0;
    for(int i=0;i<16;i++)
    {
       for(int j=0;j<16;j++)
       {   
         for(int k=0;k<16;k++)
         {
             sum1+=a[i][j][k];
         }
       }
    }
    printf("Total incompitable entries in BDT = %d \n",sum1);
         
    
}
