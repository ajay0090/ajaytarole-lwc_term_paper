#include<stdio.h>
unsigned char sbox[16]=          {0xc,0x5,0x6,0xb,0x9,0x0,0xa,0xd,0x3,0xe,0xf,0x8,0x4,0x7,0x1,0x2};
unsigned char inverse_sbox[16] = {0x5,0xe,0xf,0x8,0xc,0x1,0x2,0xd,0xb,0x4,0x6,0x3,0x0,0x7,0x9,0xa};

int main()
{
    unsigned char a[16][16]={0};
    for(int x=0;x<16;x++)
    {
        for(int i=0;i<16;i++)
        {
           for(int j=0;j<16;j++)
           {
               if(((inverse_sbox[sbox[x]^j])^(inverse_sbox[sbox[x^i]^j]))==i)
               a[i][j]++;
           }
        }
    }
    printf("---------------------BCT-----------------------\n");
    for(int i=0;i<16;i++)
    {
       for(int j=0;j<16;j++)
       {   
         if(a[i][j]<10)
         printf(" %d ",a[i][j]);
         else
         printf("%d ",a[i][j]);
         
       }
       printf("\n");
    }

}
