import sys

sbox = [0xc,0x5,0x6,0xb,0x9,0x0,0xa,0xd,0x3,0xe,0xf,0x8,0x4,0x7,0x1,0x2]
SIZE_SBOX = len(sbox)

# compute the linear approximation for a given "input = output" equation
def linearApprox(input_int, output_int):
    total = 0
    # range over the input
    for ii in range(SIZE_SBOX):
        # get input and output of our equations
        input_masked = ii & input_int
        output_masked = sbox[ii] & output_int
        # same result?
        if (bin(input_masked).count("1") - bin(output_masked).count("1")) % 2 == 0:
            total += 1 
    # get the number of results compared to 8/16
    result = total - (SIZE_SBOX//2)
    if result > 0:
        result = "+" + str(result)
    else:
        result = str(result)

    return result

def main():
    #row
    for row in range(SIZE_SBOX):
        # cols
        for col in range(SIZE_SBOX):
        # print the linear approx
            if (row == 1 or row ==2 or row == 4 or row == 8 ) and (col == 1 or col == 2 or col == 4 or col == 8) :
                sys.stdout.write( linearApprox(row, col).rjust(3) + " ")
        if (row == 1 or row ==2 or row == 4 or row == 8 ): 
            print ""

if __name__ == "__main__":
    main()
