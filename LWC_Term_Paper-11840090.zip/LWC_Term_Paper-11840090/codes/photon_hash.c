#include<stdio.h>
#include <stdlib.h>
#include<string.h>

void AddConstant(unsigned char* X, unsigned char k);
void SubCells(unsigned char* X);
void ShiftRows(unsigned char* state);
void MixColumnSerial(unsigned char* X);
void Shuffle(unsigned char* S);
void PHOTON_Beetle_Hash_32(unsigned char* M, unsigned char* T, unsigned char len);

unsigned char S_Box[16]=
{0xc,0x5,0x6,0xb,0x9,0x0,0xa,0xd,0x3,0xe,0xf,0x8,0x4,0x7,0x1,0x2};

unsigned char RC[12]=
{0x1,0x3,0x7,0xe,0xd,0xb,0x6,0xc,0x9,0x2,0x5,0xa};

unsigned char IC[8]=
{0x0,0x1,0x3,0x7,0xf,0xe,0xc,0x8};

unsigned char M[64]=
{0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x0,
 0x0,0x0,0x1,0x0,0x0,0x0,0x0,0x0,
 0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x0,
 0x0,0x0,0x0,0x0,0x1,0x0,0x0,0x0,
 0x0,0x0,0x0,0x0,0x0,0x1,0x0,0x0,
 0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x0,
 0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,
 0x2,0x4,0x2,0xb,0x2,0x8,0x5,0x6};

unsigned char Mul[256]=
{0,1,2,3,4,5,6,7,8,9,0xa,0xb,0xc,0xd,0xe,0xf,
 3,2,1,0,7,6,5,4,0xb,0xa,9,8,0xf,0xe,0xd,0xc,
 6,7,4,5,2,3,0,1,0xe,0xf,0xc,0xd,0xa,0xb,8,9,
 5,4,7,6,1,0,3,2,0xd,0xc,0xf,0xe,9,8,0xb,0xa,
 0xc,0xd,0xe,0xf,8,9,0xa,0xb,4,5,6,7,0,1,2,3,
 0xf,0xe,0xd,0xc,0xb,0xa,9,8,7,6,5,4,3,2,1,0,
 0xa,0xb,9,8,0xe,0xf,0xc,0xd,2,3,0,1,6,7,4,5,
 9,8,0xb,0xa,0xd,0xc,0xf,0xe,1,0,3,2,5,4,7,6,
 0xb,0xa,9,8,0xf,0xe,0xe,0xc,3,2,1,0,7,6,5,4,
 8,9,0xa,0xb,0xc,0xd,0xe,0xf,0,1,2,3,4,5,6,7,
 0xd,0xc,0xf,0xe,9,8,0xb,0xa,5,4,7,6,1,0,3,2,
 0xe,0xf,0xc,0xd,0xa,0xb,8,9,6,7,4,5,2,3,0,1,
 7,6,5,4,3,2,1,0,0xf,0xe,0xd,0xc,0xb,0xa,8,9,
 4,5,6,7,0,1,2,3,0xc,0xd,0xe,0xf,8,9,0xa,0xb,
 1,0,2,3,5,4,7,6,9,8,0xb,0xa,0xd,0xc,0xf,0xe,
 2,3,0,1,6,7,4,5,0xa,0xb,8,9,0xe,0xf,0xc,0xd
};
void PHOTON256(unsigned char* X)
{
    for(int i=0;i<=11;i++)// 12 rounds
    {
        AddConstant(X,i);
        SubCells(X);
        ShiftRows(X);
        MixColumnSerial(X);
    }
}

void AddConstant(unsigned char* X, unsigned char k)
{
    int j=0;
    for(int i=0;i<8;i++)
    {
        X[i]=X[i]^RC[k]^IC[i];//j++;
    }
}

void SubCells(unsigned char* X)
{
    for(int i=0;i<64;i++)
    {
            X[i]=S_Box[X[i]];//printf("%X ",X[i]);
    }
}

void ShiftRows(unsigned char* state)
{
    unsigned char tmp[64];
    tmp[0]=state[0 ];tmp[8 ]=state[8 ];tmp[16]=state[16];tmp[24]=state[24];tmp[32]=state[32];tmp[40]=state[40];tmp[48]=state[48];tmp[56]=state[56];
    tmp[1]=state[9 ];tmp[9 ]=state[17];tmp[17]=state[25];tmp[25]=state[33];tmp[33]=state[41];tmp[41]=state[49];tmp[49]=state[57];tmp[57]=state[1 ];
    tmp[2]=state[18];tmp[10]=state[26];tmp[18]=state[34];tmp[26]=state[42];tmp[34]=state[50];tmp[42]=state[58];tmp[50]=state[2 ];tmp[58]=state[10];
    tmp[3]=state[27];tmp[11]=state[35];tmp[19]=state[43];tmp[27]=state[51];tmp[35]=state[59];tmp[43]=state[3 ];tmp[51]=state[11];tmp[59]=state[19];
    tmp[4]=state[36];tmp[12]=state[44];tmp[20]=state[52];tmp[28]=state[60];tmp[36]=state[4 ];tmp[44]=state[12];tmp[52]=state[20];tmp[60]=state[28];
    tmp[5]=state[45];tmp[13]=state[53];tmp[21]=state[61];tmp[29]=state[5 ];tmp[37]=state[13];tmp[45]=state[21];tmp[53]=state[29];tmp[61]=state[37];
    tmp[6]=state[54];tmp[14]=state[62];tmp[22]=state[6]; tmp[30]=state[14];tmp[38]=state[22];tmp[46]=state[30];tmp[54]=state[38];tmp[62]=state[46];
    tmp[7]=state[63];tmp[15]=state[7]; tmp[23]=state[15];tmp[31]=state[23];tmp[39]=state[31];tmp[47]=state[39];tmp[55]=state[47];tmp[63]=state[53];
 for(int i=0;i<64;i++)
    state[i]=tmp[i];

}

void MixColumnSerial(unsigned char* X)
{
    int i, j, k,l,index=0;
    unsigned char res[64],temp=0;
    for(i=0;i<8;i++)
    {  
            for(int k=0;k<64;k=k+8)
            {
                 j=i*8;
                 for(l=k;l<8+k;l++)
                 {
                      temp+=Mul[M[j]*X[l]];j++;
                 }
                 res[index]=Mul[temp];
        
                 //printf("%d ",temp);
                 temp=0;
                 index++;
            }
    }
    for (i = 0; i < 64; i++) {
            X[i]=res[i];
    }
}


void TAG_256(unsigned char* IV)
{
    unsigned char temp[64];
    for(int i=0;i<64;i++)
    temp[i]=IV[i];
   
    PHOTON256(temp);//PHOTON256(T1)
    for(int i=0;i<32;i++)
    {IV[i]=temp[i];}//Trunc(T1,128)

    PHOTON256(temp);//PHOTON256(T2)
    for(int i=32;i<64;i++)
    {IV[i]=temp[i-32];}//Trunc(T2,128)
}

void PHOTON_Beetle_Hash_32(unsigned char* M, unsigned char* T, unsigned char len)
{
    unsigned char c0,IV[64];
    if(len==0)
    {
        for(int i=0;i<64;i++)
        {IV[i]=0;}
        IV[63]=IV[63] ^ 1;
        TAG_256(IV);
       
        for(int i=0;i<64;i++)
        {T[i]=IV[i];}

    }
    else if(len<=32)
    {
         if(len<32)
         {    
              c0=1;
              M[len]=8;//OZc 1
              for(int i=len+1;i<32;i++)
              {M[i]=0;}//OZc 0*
         }
         else
         {    c0=2;}
         for(int i=0;i<32;i++)
         {IV[i]=M[i];}
         for(int i=32;i<64;i++)
         {IV[i]=0;}
         IV[63]=IV[63] ^ c0;
         TAG_256(IV);
       
         for(int i=0;i<64;i++)
         {T[i]=IV[i];}
    }
    
}
int main()
{
     unsigned char M[32];
     unsigned char T[64];   

      //test 1
     PHOTON_Beetle_Hash_32(M,T,0);
     printf("Message: Empty");
     printf("\n"); 
     printf("Hash: ");
     for(int i=0;i<64;i++)
     {if(i%2==0 && i>0){printf(":");} printf("%X",T[i]);}
     printf("\n\n");
     
     //test 2
     for(int i=0;i<3;i++)
     {
        M[i]=3;
     }
     PHOTON_Beetle_Hash_32(M,T,3);
     printf("Message: ");
     for(int i=0;i<3;i++)
     {printf("%X",M[i]);}
     printf("\n"); 
     printf("Hash: ");
     for(int i=0;i<64;i++)
     {if(i%2==0 && i>0){printf(":");} printf("%X",T[i]);}
     printf("\n\n");
   
     //test 3
     for(int i=0;i<32;i++)
     {
        M[i]=1;
     }
     PHOTON_Beetle_Hash_32(M,T,32);
     printf("Message: ");
     for(int i=0;i<32;i++)
     {printf("%X",M[i]);}
     printf("\n"); 
     printf("Hash: ");
     for(int i=0;i<64;i++)
     {if(i%2==0 && i>0){printf(":");} printf("%X",T[i]);}
      
     printf("\n");
return 0;
}
