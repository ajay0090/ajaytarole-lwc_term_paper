#Commands for runing all the codes#



#DDT code: 

command~$ gcc DDT.c
command~$ ./a.out

It will print DDT table.



####################################################
#Incompatible Trails in DDT:

command~$ gcc DDT_incompat.c
command~$ ./a.out

It will print total numbers of incompatible trails in DDT.



####################################################
#1-1 DDT bit code:

command~$ cd 1-1DDT
command~$ gcc DDT1.c
command~$ ./a.out

It will print 1-1 bit DDT table.



####################################################
#LAT code:

command~$ python LAT.c

It will print LAT table.



####################################################
#1-1 LAT code:

command~$ cd 1-1LAT
command~$ python LAT1.py

It will print 1-1 bit LAT table.



####################################################
#BCT code:

command~$ gcc BCT.c
command~$ ./a.out

It will print BCT table.



####################################################
#BDT code:

command~$ gcc BDT.c
command~$ ./a.out

It will print BDT table.



####################################################
#Verifying BDT properties: 

command~$ gcc BDT_properties.c
command~$ ./a.out

It will print how all four properties satisfy.



####################################################
#Implement PHOTON encryption decryption to gather

command~$ gcc photon_aead.c
command~$ ./a.out

It will print output for some case like associate data or massage is empty or not empty.



####################################################
#Implement PHOTON hash fuction

command~$ gcc photon_aead.c
command~$ ./a.out

It will generate hash value of massage.


####################################################
#Verify Zero-Sum Property

command~$ gcc Zero_Sum.c
command~$ ./a.out

It will verify for 1 round  and 2 rounds Zero Sum result. 




######################################################################
#S box properties like component functions, max degree , min degree

I used CoCalc.com to execute sbox.ipynb 

To run this notebook you need Sage library.

I put the notebook code below you can just copy paste and run.

#sbox.ipynb

from sage.crypto.sbox import SBox
PHOTON_SBOX = SBox([12,5,6,11,9,0,10,13,3,14,15,8,4,7,1,2])
PHOTON_SBOX.max_degree()

Output: 3

print("PHOTON_SBOX")
print("Main componets function")
f3 = PHOTON_SBOX.component_function(2**3)
print("\ty3 = ",f3.algebraic_normal_form())
f2 = PHOTON_SBOX.component_function(2**2)
print("\ty2 = ",f2.algebraic_normal_form())
f1 = PHOTON_SBOX.component_function(2**1)
print("\ty1 = ",f1.algebraic_normal_form())
f0 = PHOTON_SBOX.component_function(2**0)
print("\ty0 = ",f0.algebraic_normal_form())
print("\n")
print("All componets function")
f15 = PHOTON_SBOX.component_function(15)
print("\ty15 = ",f15.algebraic_normal_form())
f14 = PHOTON_SBOX.component_function(14)
print("\ty14 = ",f14.algebraic_normal_form())
f13 = PHOTON_SBOX.component_function(13)
print("\ty13 = ",f13.algebraic_normal_form())
f12 = PHOTON_SBOX.component_function(12)
print("\ty12 = ",f12.algebraic_normal_form())
f11 = PHOTON_SBOX.component_function(11)
print("\ty11 = ",f11.algebraic_normal_form())
f10 = PHOTON_SBOX.component_function(10)
print("\ty10 = ",f10.algebraic_normal_form())
f9 = PHOTON_SBOX.component_function(9)
print("\ty9  = ",f9.algebraic_normal_form())
f8 = PHOTON_SBOX.component_function(8)
print("\ty8  = ",f8.algebraic_normal_form())
f7 = PHOTON_SBOX.component_function(7)
print("\ty7  = ",f7.algebraic_normal_form())
f6 = PHOTON_SBOX.component_function(6)
print("\ty6  = ",f6.algebraic_normal_form())
f5 = PHOTON_SBOX.component_function(5)
print("\ty5  = ",f5.algebraic_normal_form())
f4 = PHOTON_SBOX.component_function(4)
print("\ty4  = ",f4.algebraic_normal_form())
f3 = PHOTON_SBOX.component_function(3)
print("\ty3  = ",f3.algebraic_normal_form())
f2 = PHOTON_SBOX.component_function(2)
print("\ty2  = ",f2.algebraic_normal_form())
f1 = PHOTON_SBOX.component_function(1)
print("\ty1  = ",f1.algebraic_normal_form())
f0 = PHOTON_SBOX.component_function(0)
print("\ty0  = ",f0.algebraic_normal_form())



Output: 
PHOTON_SBOX
Main componets function
	y3 =  x0*x1*x2 + x0*x1*x3 + x0*x2*x3 + x0 + x1*x2 + x1 + x3 + 1
	y2 =  x0*x1*x3 + x0*x1 + x0*x2*x3 + x0*x3 + x1*x3 + x2 + x3 + 1
	y1 =  x0*x1*x2 + x0*x1*x3 + x0*x2*x3 + x1*x3 + x1 + x2*x3 + x3
	y0 =  x0 + x1*x2 + x2 + x3


All componets function
	y15 =  x0*x1*x3 + x0*x1 + x0*x2*x3 + x0*x3 + x2*x3
	y14 =  x0*x1*x3 + x0*x1 + x0*x2*x3 + x0*x3 + x0 + x1*x2 + x2*x3 + x2 + x3
	y13 =  x0*x1*x2 + x0*x1 + x0*x3 + x1*x3 + x1 + x3
	y12 =  x0*x1*x2 + x0*x1 + x0*x3 + x0 + x1*x2 + x1*x3 + x1 + x2
	y11 =  x1*x3 + x2*x3 + x2 + x3 + 1
	y10 =  x0 + x1*x2 + x1*x3 + x2*x3 + 1
	y9  =  x0*x1*x2 + x0*x1*x3 + x0*x2*x3 + x1 + x2 + 1
	y8  =  x0*x1*x2 + x0*x1*x3 + x0*x2*x3 + x0 + x1*x2 + x1 + x3 + 1
	y7  =  x0*x1*x2 + x0*x1 + x0*x3 + x0 + x1*x2 + x1 + x2*x3 + x3 + 1
	y6  =  x0*x1*x2 + x0*x1 + x0*x3 + x1 + x2*x3 + x2 + 1
	y5  =  x0*x1*x3 + x0*x1 + x0*x2*x3 + x0*x3 + x0 + x1*x2 + x1*x3 + 1
	y4  =  x0*x1*x3 + x0*x1 + x0*x2*x3 + x0*x3 + x1*x3 + x2 + x3 + 1
	y3  =  x0*x1*x2 + x0*x1*x3 + x0*x2*x3 + x0 + x1*x2 + x1*x3 + x1 + x2*x3 + x2
	y2  =  x0*x1*x2 + x0*x1*x3 + x0*x2*x3 + x1*x3 + x1 + x2*x3 + x3
	y1  =  x0 + x1*x2 + x2 + x3
	y0  =  0


PHOTON_SBOX.maximal_difference_probability()

Output: 0.25

PHOTON_SBOX.min_degree()

Output: 2

PHOTON_SBOX.differential_branch_number()

Output: 3

PHOTON_SBOX.linear_branch_number()

Output: 2






