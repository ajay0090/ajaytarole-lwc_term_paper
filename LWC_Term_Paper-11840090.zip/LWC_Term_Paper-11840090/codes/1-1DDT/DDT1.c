#include<stdio.h>
int sbox[16]={0xc,0x5,0x6,0xb,0x9,0x0,0xa,0xd,0x3,0xe,0xf,0x8,0x4,0x7,0x1,0x2};
int main()
{
    int a[16][16]={0},k,l;
    for(int i=0;i<16;i++)
    {
        for(int j=0;j<16;j++)
        {
             k=sbox[i]^sbox[j];
             l=i^j;
            a[l][k]++;
        }
    }
    for(int i=0;i<16;i++)
    {
       for(int j=0;j<16;j++)
       {
           if((i==1 || i==2 || i==4 || i==8)  && (j==1 || j==2 || j==4 || j==8 ))
           {printf("%d ",a[i][j]);}
       }
       if((i==1 || i==2 || i==4 || i==8)) 
       printf("\n");
       
    }

}
