#include<stdio.h>
#include <stdlib.h>
#include<string.h>

void AddConstant(unsigned char* X, unsigned char k);
void SubCells(unsigned char* X);
void ShiftRows(unsigned char* state);
void MixColumnSerial(unsigned char* X);
void Shuffle(unsigned char* S);
void PHOTON_Beetle_Hash_32(unsigned char* M, unsigned char* T, unsigned char len);

unsigned char S_Box[16]=
{0xc,0x5,0x6,0xb,0x9,0x0,0xa,0xd,0x3,0xe,0xf,0x8,0x4,0x7,0x1,0x2};

unsigned char RC[12]=
{0x1,0x3,0x7,0xe,0xd,0xb,0x6,0xc,0x9,0x2,0x5,0xa};

unsigned char IC[8]=
{0x0,0x1,0x3,0x7,0xf,0xe,0xc,0x8};

unsigned char M[64]=
{0x0,0x1,0x0,0x0,0x0,0x0,0x0,0x0,
 0x0,0x0,0x1,0x0,0x0,0x0,0x0,0x0,
 0x0,0x0,0x0,0x1,0x0,0x0,0x0,0x0,
 0x0,0x0,0x0,0x0,0x1,0x0,0x0,0x0,
 0x0,0x0,0x0,0x0,0x0,0x1,0x0,0x0,
 0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x0,
 0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x1,
 0x2,0x4,0x2,0xb,0x2,0x8,0x5,0x6};

unsigned char Mul[256]=
{0,1,2,3,4,5,6,7,8,9,0xa,0xb,0xc,0xd,0xe,0xf,
 3,2,1,0,7,6,5,4,0xb,0xa,9,8,0xf,0xe,0xd,0xc,
 6,7,4,5,2,3,0,1,0xe,0xf,0xc,0xd,0xa,0xb,8,9,
 5,4,7,6,1,0,3,2,0xd,0xc,0xf,0xe,9,8,0xb,0xa,
 0xc,0xd,0xe,0xf,8,9,0xa,0xb,4,5,6,7,0,1,2,3,
 0xf,0xe,0xd,0xc,0xb,0xa,9,8,7,6,5,4,3,2,1,0,
 0xa,0xb,9,8,0xe,0xf,0xc,0xd,2,3,0,1,6,7,4,5,
 9,8,0xb,0xa,0xd,0xc,0xf,0xe,1,0,3,2,5,4,7,6,
 0xb,0xa,9,8,0xf,0xe,0xe,0xc,3,2,1,0,7,6,5,4,
 8,9,0xa,0xb,0xc,0xd,0xe,0xf,0,1,2,3,4,5,6,7,
 0xd,0xc,0xf,0xe,9,8,0xb,0xa,5,4,7,6,1,0,3,2,
 0xe,0xf,0xc,0xd,0xa,0xb,8,9,6,7,4,5,2,3,0,1,
 7,6,5,4,3,2,1,0,0xf,0xe,0xd,0xc,0xb,0xa,8,9,
 4,5,6,7,0,1,2,3,0xc,0xd,0xe,0xf,8,9,0xa,0xb,
 1,0,2,3,5,4,7,6,9,8,0xb,0xa,0xd,0xc,0xf,0xe,
 2,3,0,1,6,7,4,5,0xa,0xb,8,9,0xe,0xf,0xc,0xd
};

void Rho(unsigned char* S, unsigned char* U)
{
    //Trunc(Shuffle(S),sizeof(S)/sizeof(char*))^U; // V
    //S=S^Ozs_r(U);// S
    unsigned char V[32],S1[32];
    for(int i=0;i<32;i++)
    S1[i]=S[i];

    Shuffle(S1);
    for(int i=0;i<32;i++)
    {    V[i]=S1[i]^U[i];} //V

    for(int i=0;i<32;i++)
    {    S[i]=S[i]^U[i];}
    for(int i=0;i<32;i++)
    {U[i]=V[i];}
}

void Rho_inv(unsigned char* S, unsigned char* V)
{
    //Trunc(Shuffle(S),sizeof(S)/sizeof(char*))^U; // V
    //S=S^Ozs_r(U);// S
    unsigned char U[32],S1[32];
    for(int i=0;i<32;i++)
    S1[i]=S[i];

    Shuffle(S1);
    for(int i=0;i<32;i++)
    {    U[i]=S1[i]^V[i];} //V

    for(int i=0;i<32;i++)
    {    S[i]=S[i]^U[i];}
    for(int i=0;i<32;i++)
    {V[i]=U[i];}
}

void Shuffle(unsigned char* S)
{
    unsigned char S1[16],S2[16],plain[64],temp;
    for(int i=0;i<16;i++)  //r/2
        S1[i]=S[i];
    for(int i=16;i<32;i++) //r/2
        S2[i-16]=S[i];  
   
    int l=0;
    for(int j=0;j<16;j++)
    {
          if(S1[j]==0)
          {plain[l]=0;plain[l+1]=0;plain[l+2]=0;plain[l+3]=0;}
          else if(S1[j]==1)
          {plain[l]=0;plain[l+1]=0;plain[l+2]=0;plain[l+3]=1;}
          else if(S1[j]==2)
          {plain[l]=0;plain[l+1]=0;plain[l+2]=1;plain[l+3]=0;}
          else if(S1[j]==3)
          {plain[l]=0;plain[l+1]=0;plain[l+2]=1;plain[l+3]=1;}
          else if(S1[j]==4)
          {plain[l]=0;plain[l+1]=1;plain[l+2]=0;plain[l+3]=0;}
          else if(S1[j]==5)
          {plain[l]=0;plain[l+1]=1;plain[l+2]=0;plain[l+3]=1;}
          else if(S1[j]==6)
          {plain[l]=0;plain[l+1]=1;plain[l+2]=1;plain[l+3]=0;}
          else if(S1[j]==7)
          {plain[l]=0;plain[l+1]=1;plain[l+2]=1;plain[l+3]=1;}
          else if(S1[j]==8)
          {plain[l]=1;plain[l+1]=0;plain[l+2]=0;plain[l+3]=0;}
          else if(S1[j]==9)
          {plain[l]=1;plain[l+1]=0;plain[l+2]=0;plain[l+3]=1;}
          else if(S1[j]==10)
          {plain[l]=1;plain[l+1]=0;plain[l+2]=1;plain[l+3]=0;}
          else if(S1[j]==11)
          {plain[l]=1;plain[l+1]=0;plain[l+2]=1;plain[l+3]=1;}
          else if(S1[j]==12)
          {plain[l]=1;plain[l+1]=1;plain[l+2]=0;plain[l+3]=0;}
          else if(S1[j]==13)
          {plain[l]=1;plain[l+1]=1;plain[l+2]=0;plain[l+3]=1;}
          else if(S1[j]==14)
          {plain[l]=1;plain[l+1]=1;plain[l+2]=1;plain[l+3]=0;}
          else if(S1[j]==15)
          {plain[l]=1;plain[l+1]=1;plain[l+2]=1;plain[l+3]=1;}
          
          l=l+4;

    }

    temp=plain[63];
    for(int i=63;i>0;i--)  // S1 >>> 1
    {
        plain[i]=plain[i-1];
    }
    plain[0]=temp;
    
    for(int i=0;i<16;i++)
     {
         int t1=0,t2=8,t3;
         for(int k=i*4;k<4*(i+1);k++)
         {
           t1+=t2*(plain[k]%2);
           t2/=2;
         }
         S1[i]=t1;
     }
     

    //S=S1||S2
    for(int i=0;i<16;i++)  //r/2
        S[i]=S2[i];
    for(int i=16;i<32;i++) //r/2
        S[i]=S1[i-16];  
    
}

void PHOTON256(unsigned char* X)
{
    for(int i=0;i<=11;i++)// 12 rounds
    {
        AddConstant(X,i);
        SubCells(X);
        ShiftRows(X);
        MixColumnSerial(X);
    }
}

void AddConstant(unsigned char* X, unsigned char k)
{
    int j=0;
    for(int i=0;i<8;i++)
    {
        X[i]=X[i]^RC[k]^IC[i];//j++;
    }
}

void SubCells(unsigned char* X)
{
    for(int i=0;i<64;i++)
    {
            X[i]=S_Box[X[i]];//printf("%X ",X[i]);
    }
}

void ShiftRows(unsigned char* state)
{
    unsigned char tmp[64];
    tmp[0]=state[0 ];tmp[8 ]=state[8 ];tmp[16]=state[16];tmp[24]=state[24];tmp[32]=state[32];tmp[40]=state[40];tmp[48]=state[48];tmp[56]=state[56];
    tmp[1]=state[9 ];tmp[9 ]=state[17];tmp[17]=state[25];tmp[25]=state[33];tmp[33]=state[41];tmp[41]=state[49];tmp[49]=state[57];tmp[57]=state[1 ];
    tmp[2]=state[18];tmp[10]=state[26];tmp[18]=state[34];tmp[26]=state[42];tmp[34]=state[50];tmp[42]=state[58];tmp[50]=state[2 ];tmp[58]=state[10];
    tmp[3]=state[27];tmp[11]=state[35];tmp[19]=state[43];tmp[27]=state[51];tmp[35]=state[59];tmp[43]=state[3 ];tmp[51]=state[11];tmp[59]=state[19];
    tmp[4]=state[36];tmp[12]=state[44];tmp[20]=state[52];tmp[28]=state[60];tmp[36]=state[4 ];tmp[44]=state[12];tmp[52]=state[20];tmp[60]=state[28];
    tmp[5]=state[45];tmp[13]=state[53];tmp[21]=state[61];tmp[29]=state[5 ];tmp[37]=state[13];tmp[45]=state[21];tmp[53]=state[29];tmp[61]=state[37];
    tmp[6]=state[54];tmp[14]=state[62];tmp[22]=state[6]; tmp[30]=state[14];tmp[38]=state[22];tmp[46]=state[30];tmp[54]=state[38];tmp[62]=state[46];
    tmp[7]=state[63];tmp[15]=state[7]; tmp[23]=state[15];tmp[31]=state[23];tmp[39]=state[31];tmp[47]=state[39];tmp[55]=state[47];tmp[63]=state[53];
 for(int i=0;i<64;i++)
    state[i]=tmp[i];

}

void MixColumnSerial(unsigned char* X)
{
    int i, j, k,l,index=0;
    unsigned char res[64],temp=0;
    for(i=0;i<8;i++)
    {  
            for(int k=0;k<64;k=k+8)
            {
                 j=i*8;
                 for(l=k;l<8+k;l++)
                 {
                      temp+=Mul[M[j]*X[l]];j++;
                 }
                 res[index]=Mul[temp];
        
                 //printf("%d ",temp);
                 temp=0;
                 index++;
            }
    }
    for (i = 0; i < 64; i++) {
            X[i]=res[i];
    }
}

void TAG_128(unsigned char* T0)
{
    PHOTON256(T0);
}

void HASH_128(unsigned char* IV, unsigned char* D, unsigned char c0,unsigned char a)
{
    unsigned char Y[32],Z[32],W[32];
    //D1||D2 r Ozs_r(D); r=128
    //for i=1 to d
    PHOTON256(IV);

    //Y||Z (r,256-r) PHOTON256
    for(int i=0;i<32;i++)
        Y[i]=IV[i];
    for(int i=32;i<64;i++)
        Z[i-32]=IV[i];

    //IV=W||Z
    for(int i=0;i<32;i++)
        W[i]=Y[i] ^ D[i];
    for(int i=0;i<32;i++)
        IV[i]=W[i];
    for(int i=32;i<64;i++)
        IV[i]=Z[i-32];    

    //IV=IV ^ c0
    IV[63]=IV[63] ^ c0;
}

void PHOTON_Beetle_AEAD_ENC_r(unsigned char* K, unsigned char* N, unsigned char* A, unsigned char* M, unsigned char* T,unsigned char m,unsigned char a)
{
     unsigned char IV[64],c0,c1,Y[32],Z[32];

     //IV=N||K 
     for(int i=0;i<32;i++)
     {IV[i]=N[i];}
     for(int i=32;i<64;i++)
     {IV[i]=K[i-32];}     
     
     //c0
     if((m!=0) && (a/128)){c0=1;}else if(m!=0){c0=2;}else if(a/128){c0=3;}else{c0=4;}
     
     //c1
     if((a!=0) && (m/128)){c1=1;}else if(a!=0){c1=2;}else if(m/128){c1=5;}else{c1=6;}

     if(a==0 && m==0)
     {
        IV[63]=IV[63] ^ 1;
        TAG_128(IV);
        for(int i=0;i<32;i++)
        {
            T[i]=IV[i];
        }
     } 
     if(a!=0)
     {
         HASH_128(IV,A,c0,a);
     }
     if(m!=0)
     {
        PHOTON256(IV);
         //Y||Z
        for(int i=0;i<32;i++)
        Y[i]=IV[i];
        for(int i=32;i<64;i++)
        Z[i-32]=IV[i];    

        //rho
        Rho(Y,M); //W=Y and C=M       
        for(int i=0;i<32;i++)
        IV[i]=Y[i];
        for(int i=32;i<64;i++)
        IV[i]=Z[i-32];

        //IV=IV ^ c1
        IV[63]=IV[63] ^ c1;

     }
     TAG_128(IV);
     for(int i=0;i<32;i++)
        {T[i]=IV[i];}
     
}

void PHOTON_Beetle_AEAD_DEC_r(unsigned char* K, unsigned char* N, unsigned char* A,unsigned char* C, unsigned char* T,unsigned char* T1,unsigned char m,unsigned char a)
{
     unsigned char IV[64],c0,c1,Y[32],Z[32];

     //IV=N||K 
     for(int i=0;i<32;i++)
     {IV[i]=N[i];}
     for(int i=32;i<64;i++)
     {IV[i]=K[i-32];}     
     
     //c0
     if(m!=0 && a/128){c0=1;}else if(m!=0){c0=2;}else if(a/128){c0=3;}else{c0=4;}
     
     //c1
     if(a!=0 && m/128){c1=1;}else if(a!=0){c1=2;}else if(m/128){c1=5;}else{c1=6;}

     if(a==0 && m==0)
     {
        IV[63]=IV[63] ^ 1;
        TAG_128(IV);
        for(int i=0;i<32;i++)
        {
            T1[i]=IV[i];
        }
     } 
     if(a!=0)
     {
         HASH_128(IV,A,c0,a);
     }
     if(m!=0)
     {
        PHOTON256(IV);
         //Y||Z
        for(int i=0;i<32;i++)
        Y[i]=IV[i];
        for(int i=32;i<64;i++)
        Z[i-32]=IV[i];    

        //rho
        Rho_inv(Y,C); //W=Y and C=M       
        for(int i=0;i<32;i++)
        IV[i]=Y[i];
        for(int i=32;i<64;i++)
        IV[i]=Z[i-32];

        //IV=IV ^ c1
        IV[63]=IV[63] ^ c1;

     }
     TAG_128(IV);
     for(int i=0;i<32;i++)
        {T1[i]=IV[i];}
     
     int c=0;
     for(int i=0;i<32;i++)
     {
         if(T1[i]==T[i])
         c++;
     }
     /*if(c==32)
     {
        printf("Match\n");
     }
     else
     {
        printf("Error\n");
     }*/
}

int main()
{
     unsigned char K[32],N[32],A[32],M[32];
     unsigned char T[32],T1[32];

     printf("Test 1: Both are non-empty\n");
     for(int i=0;i<32;i++)
     {
        K[i]=1;N[i]=1;A[i]=2;M[i]=7;
     }
     printf("Encryption:\n");
     int m=32;//length of message
     int a=32;//length of associated data

     PHOTON_Beetle_AEAD_ENC_r(K,N,A,M,T,m,a);
     printf("T = ");
     for(int i=0;i<32;i++)
     {   if(i%2==0 && i>0){printf(":");}printf("%X",T[i]);}
     printf("\n");
     printf("C = ");
     for(int i=0;i<32;i++)
     {  printf("%X ",M[i]);}
     printf("\n");
     PHOTON_Beetle_AEAD_DEC_r(K,N,A,M,T,T1,m,a);
     printf("Decryption:\n");
     printf("T*= ");
     for(int i=0;i<32;i++)
     {if(i%2==0 && i>0){printf(":");} printf("%X",T1[i]);}
     printf("\n");
     printf("M = ");
     for(int i=0;i<32;i++)
     {  printf("%X ",M[i]);}
     printf("\n");

     unsigned char K1[32],N1[32],A1[32],M1[32],T2[32],T3[32];
     printf("\nTest 2: AD is non-empty\n");
     for(int i=0;i<32;i++)
     {
        K1[i]=1;N1[i]=1;A1[i]=2;
     }
     printf("Encryption:\n");
     m=0;//length of message
     a=32;//length of associated data

     PHOTON_Beetle_AEAD_ENC_r(K1,N1,A1,M1,T2,m,a);
     printf("T = ");
     for(int i=0;i<32;i++)
     {   if(i%2==0 && i>0){printf(":");}printf("%X",T2[i]);}
     printf("\n");
     printf("C = Empty");
     printf("\n");
     PHOTON_Beetle_AEAD_DEC_r(K1,N1,A1,M1,T2,T3,m,a);
     printf("Decryption:\n");
     printf("T*= ");
     for(int i=0;i<32;i++)
     {if(i%2==0 && i>0){printf(":");} printf("%X",T3[i]);}
     printf("\n");
     printf("M = Empty");
     printf("\n");
 
     unsigned char K2[32],N2[32],A2[32],M2[32],T4[32],T5[32];
     printf("\nTest 3: Message is non-empty\n");
     for(int i=0;i<32;i++)
     {
        K2[i]=1;N2[i]=1;M2[i]=7;
     }
     printf("Encryption:\n");
     m=32;//length of message
     a=0;//length of associated data

     PHOTON_Beetle_AEAD_ENC_r(K2,N2,A2,M2,T4,m,a);
     printf("T = ");
     for(int i=0;i<32;i++)
     {   if(i%2==0 && i>0){printf(":");}printf("%X",T4[i]);}
     printf("\n");
     printf("C = ");
     for(int i=0;i<32;i++)
     {  printf("%X ",M2[i]);}
     printf("\n");
     PHOTON_Beetle_AEAD_DEC_r(K2,N2,A2,M2,T4,T5,m,a);
     printf("Decryption:\n");
     printf("T*= ");
     for(int i=0;i<32;i++)
     {if(i%2==0 && i>0){printf(":");} printf("%X",T5[i]);}
     printf("\n");
     printf("M = ");
     for(int i=0;i<32;i++)
     {  printf("%X ",M2[i]);}
     printf("\n");
 
     unsigned char K3[32],N3[32],A3[32],M3[32],T6[32],T7[32];
     printf("\nTest 4: Both are empty\n");
     for(int i=0;i<32;i++)
     {
        K3[i]=1;N3[i]=1;
     }
     printf("Encryption:\n");
     m=0;//length of message
     a=0;//length of associated data

     PHOTON_Beetle_AEAD_ENC_r(K3,N3,A3,M3,T6,m,a);
     printf("T = ");
     for(int i=0;i<32;i++)
     {   if(i%2==0 && i>0){printf(":");}printf("%X",T6[i]);}
     printf("\n");
     printf("C = Empty");
     printf("\n");
     PHOTON_Beetle_AEAD_DEC_r(K3,N3,A3,M3,T6,T7,m,a);
     printf("Decryption:\n");
     printf("T*= ");
     for(int i=0;i<32;i++)
     {if(i%2==0 && i>0){printf(":");} printf("%X",T7[i]);}
     printf("\n");
     printf("M = Empty");
     printf("\n");
 
return 0;
}
